# KL 329 judikatūras projekta bāze
## 1. Datubāzes apjoms
- Faili apstrādāti: **55**
- Unikāli teksti pēc SHA-256: **54**
- Failu tipi: {'.pdf': 46, '.docx': 6, '.doc': 3}
## 2. Galvenās Senāta atziņas
- **Priekšmets**: Neizpaužamas ziņas ir informācija, kas nav valsts noslēpums, bet kurai normatīvajā aktā paredzēta īpaša izmantošanas kārtība vai izplatīšanas aizliegums.
- **Objektīvā puse**: KL 329 objektīvo pusi veido valsts amatpersonai amata pienākumu dēļ pieejamu ziņu izpaušana vai izmantošana mērķiem ārpus amata pienākumiem, ja informācija nokļūst pie vēl vismaz vienas personas.
- **Formāls sastāvs**: Nodarījums ir pabeigts ar izpaušanas brīdi neatkarīgi no seku iestāšanās un neatkarīgi no izpaustās informācijas apjoma.
- **Iepazīšanās vs izpaušana**: KL 329 paredz atbildību nevis par iepazīšanos ar ziņām, bet par šo ziņu izpaušanu.
- **Adresāta tiesības**: Tas, ka adresāts teorētiski varētu informāciju iegūt pats vai jau bija informēts, pats par sevi nepadara nodošanu tiesisku; jāvērtē normatīvais informācijas izmantošanas režīms.
- **Publiska pieejamība**: Informācijas sistēmas vai publiskošanas režīma trūkumi nepadara aizsargātu informāciju par vispārpieejamu.
- **Uzkūdīšana**: Uzkūdīšana var izpausties kā priekšlikums vai lūgums iegūt/izpaust konkrētu informāciju.
- **Normu konkurence**: Ja izpaušana vienlaikus ir dienesta stāvokļa ļaunprātīga izmantošana ar būtisku kaitējumu, nodarījums kvalificējams pēc KL 318; kopība ar KL 329 neveidojas.
- **Nav blanketa norma**: Senāts norādījis, ka KL 329 nav blanketa norma, jo dispozīcijā norādītas sastāva pazīmes; tomēr konkrētās informācijas režīma pierādīšanai praktiski jāanalizē speciālie akti un iekšējie noteikumi.
- **Operatīvie pierādījumi**: Vecākās lietās, kad KL 329 bija kriminālpārkāpums, Senāts vairākkārt prasīja izvērtēt sevišķā veidā iegūtu operatīvo ziņu izmantošanas samērīgumu un pieļaujamību.

## 3. Biežākie pierādījumu veidi korpusā
- informacijas_sistemas: 53
- amatdokumenti: 52
- telefonsarunas: 40
- liecinieki: 37
- epasts: 30
- sms: 24
- operativa_noklausisanas: 21
- kratishana_apskate: 20
- xry_telefonu_apskate: 17
- video: 9
- whatsapp: 9
- auditacijas_dati: 7
- messenger: 3
- DNS: 2
- signal: 2
- fonoskopija: 1

## 4. Biežākie izpaustās informācijas priekšmeti
- aizturesana_kriminalprocess: 55
- tiesu_nolemumi: 55
- robeza_muita: 51
- personas_dati: 47
- nodoklu_maksatajs: 40
- kriminallietas_materiali: 35
- sodamiba: 27
- auto_ipasnieks: 26
- operativas_zinas: 17
- lauliba_privata_dzive: 15
- iepirkums: 4

## 5. Aizstāvības darba virzieni
### Vai informācija vispār ir neizpaužama?
- Aizstāvības leņķis: Prasīt precīzi identificēt informācijas režīmu, izmantošanas kārtību, izplatīšanas aizliegumu un to, vai tieši šī ziņu kombinācija bija aizsargāta.
- Prokuratūras tipiskais pretarguments: Atsauce uz IAL, speciālo likumu, iestādes sarakstu, amata aprakstu, DVS iepazīšanos, IS lietošanas noteikumiem.

### Vai notika izpaušana, ne tikai apskate?
- Aizstāvības leņķis: Atdalīt piekļuvi/iepazīšanos no nodošanas citai personai; prasīt pierādījumus par nodošanas faktu, saturu un adresātu.
- Prokuratūras tipiskais pretarguments: Telefonsarunas, SMS/WhatsApp/Messenger, liecinieki, ekrāna aplūkošana, e-pasta pielikumi.

### Vai informācija bija nodota tiesiski?
- Aizstāvības leņķis: Pierādīt amata pienākumu, konkrētu darba uzdevumu, administratīvās lietas vajadzību vai tiesisku informācijas aprites kanālu.
- Prokuratūras tipiskais pretarguments: Personisks motīvs, lūgums no paziņas/kolēģa/radinieka, datu izmantošana ārpus dienesta nepieciešamības.

### Publiski pieejama vai jau zināma informācija
- Aizstāvības leņķis: Pārbaudīt, vai precīza ziņu kombinācija bija publiski pieejama tieši izpaušanas brīdī un vai apsūdzētais to tiešām ieguva publiski.
- Prokuratūras tipiskais pretarguments: Senāta atziņa: teorētiska vai daļēja publiska pieejamība nenovērš atbildību, ja informācija iegūta no dienesta sistēmas.

### Pierādījumu pieļaujamība
- Aizstāvības leņķis: Īpaši pārbaudīt operatīvo darbību tiesisko pamatu, samērīgumu, tiesneša akceptu, datu nodošanas ķēdi, spoguļkopiju un apskates protokolu integritāti.
- Prokuratūras tipiskais pretarguments: Pēc 2016. gada KL 329 klasificēts kā mazāk smags noziegums; jaunākās lietās operatīvo ziņu izmantošana var būt vieglāk pamatota, bet joprojām jāpārbauda.

### Tiešs nodoms
- Aizstāvības leņķis: Analizēt, vai persona apzinājās informācijas režīmu un prettiesisku nodošanu; izmantot neskaidrus iekšējos noteikumus, apmācību trūkumu, amata funkciju robežas.
- Prokuratūras tipiskais pretarguments: Amata apraksti, apliecinājumi, DVS iepazīšanās, IS brīdinājumi, iepriekšēja prakse.

### Uzkūdīšana
- Aizstāvības leņķis: Atdalīt vienkāršu jautājumu/interesi no pamudināšanas; vērtēt, vai lūgums bija konkrēts un vai bija saprotams, ka informācija iegūstama no dienesta resursa.
- Prokuratūras tipiskais pretarguments: Senāts atzinis, ka uzkūdīšana var būt arī lūgums vai priekšlikums, īpaši pazīstamu personu starpā.

### KL 318 pret KL 329
- Aizstāvības leņķis: Ja apsūdzība veidota kumulatīvi pēc 318 un 329, pārbaudīt normu konkurenci un dubultu kvalifikāciju.
- Prokuratūras tipiskais pretarguments: Ja ir būtisks kaitējums, prokuratūra var virzīt 318 kā plašāku normu.

## 6. Faili/dublikāti
- Dublikāti: SKK-175-2026 (1).docx, SKK-175-2026.docx
