# Lexu / KL 329 pilot database

Izveidota strukturēta datubāze KL 329 pilotprojektam. Tā ir sagatavota kā lokāls SQLite prototips un kā Supabase/PostgreSQL importēšanas shēmas sākums.

## Galvenie faili

- `lexu_kl329_pilot.sqlite` — lokāla SQLite datubāze ar pilnu strukturēto modeli.
- `schema_sqlite.sql` — SQLite shēma.
- `schema_supabase_postgres.sql` — Supabase/PostgreSQL shēmas projekts turpmākai mākoņa migrācijai.
- `csv_export/` — visas tabulas CSV formātā, lai tās varētu importēt Supabase, BigQuery, Airtable, Excel u.c.
- `data_dictionary.csv` — tabulu un lauku vārdnīca.
- `database_summary.json` — skaitliskais kopsavilkums.

## Ko datubāze ietver

- Lietas un dokumenti: `cases`, `documents`.
- Pilnteksta meklēšana: `document_texts_fts`, `text_chunks_fts`.
- Ontoloģija: `ontology_nodes`, `ontology_edges`.
- Kontrolētā vārdnīca un piesaiste: `controlled_terms`, `case_terms`.
- Amatpersonas/personas: `persons`, `official_positions`.
- Iestādes un lomas: `institutions`, `institution_case_roles`.
- Sistēmas un avoti: `information_systems`, `case_systems`.
- Ierīces un digitālie rīki: `devices`, `forensic_tools`, `case_forensic_tools`.
- Komunikācijas kanāli: `communication_channels`.
- Pierādījumi: `evidence_items`.
- Aizstāvības argumenti: `defence_arguments`.
- Analītiskie skati: `v_case_overview`, `v_top_institutions`, `v_top_evidence`, `v_top_information_sources`, `v_defence_argument_results`.

## Pašreizējais apjoms

- Dokumenti: 54
- Lietas/grupas: 45
- Teksta fragmenti: 498
- Personas/amatpersonu pieminējumi: 19
- Iestāžu lomu ieraksti: 249
- Pierādījumu ieraksti: 260
- Aizstāvības argumentu ieraksti: 211

## Piezīme par kvalitāti

Daļa klasifikācijas ir automātiski iegūta no nolēmumu tekstiem un iepriekšējās ontoloģijas. Lauki ar `auto`, `auto_detected` vai `needs_review` jāvalidē juristam pirms izmantošanas tiesvedībā vai publiskā produktā.
