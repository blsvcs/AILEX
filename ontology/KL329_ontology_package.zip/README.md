# KL329 ontoloģijas pakotne

Faili:
- KL329_ontology_report.md — cilvēkam lasāms juridiskais modelis.
- KL329_ontology.json — mašīnlasāms ontoloģijas grafiks.
- KL329_ontology_nodes.csv — mezglu katalogs.
- KL329_ontology_edges.csv — attiecību katalogs.

Šī pakotne paredzēta kā pamats advokātu/juristu rīkam: argumentu meklēšanai, lietu salīdzināšanai, pierādījumu kontroles sarakstiem un jautājumu-atbilžu sistēmai par KL 329. pantu.
